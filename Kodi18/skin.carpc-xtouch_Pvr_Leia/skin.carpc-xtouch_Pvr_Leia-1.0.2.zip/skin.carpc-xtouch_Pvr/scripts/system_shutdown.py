import os
import xbmc

xbmc.executebuiltin('XBMC.Quit');
XBMC.Powerdown()
