import os
import xbmc
import xbmcgui

#ret = xbmcgui.Dialog().yesno("Touch Screen Calibration","Your touch screen is not calibrated. Do you want to calibrate it?")

#if os.path.isfile("/home/pi/touchscreen_axes_calib") == False:
#	if ret == 1:
#	xbmc.executebuiltin("RunScript(plugin.program.touchCalibration)")
#xbmcgui.Dialog().ok("Touch Screen Calibration","Your touch screen is not calibrated. Use a keyboard to advance through the calibration points")
