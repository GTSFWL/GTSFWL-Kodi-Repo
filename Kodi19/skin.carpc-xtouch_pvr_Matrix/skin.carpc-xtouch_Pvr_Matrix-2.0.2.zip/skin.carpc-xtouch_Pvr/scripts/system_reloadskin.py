import os
import xbmc

xbmc.executebuiltin('XBMC.ReloadSkin()');
